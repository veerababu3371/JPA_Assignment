package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;



import com.cg.entities.Hotel;
import com.cg.service.HotelService;
@Controller
public class HotelController {
	@Autowired
	private HotelService hotelService;
	
	/***********************************************************
	 * Method Name: showHomePage(Model model) Return type:String
	 * Parameters:Object of type Model Description:This method returns the name
	 * of the view that is to be displayed on the browser.
	 * 
	 * @author  
	 ***********************************************************/

	@RequestMapping("/index.obj") 
	public String getHomePage(Model model) {
		model.addAttribute("htlList", hotelService.showAllhotel());
		 ;
		model.addAttribute("hotel", new Hotel());
		 
		model.addAttribute("list", new Hotel());
		return "index";
	}

	@RequestMapping(value = "/save.obj", method = RequestMethod.POST)
	
	public String saveEmployee(@ModelAttribute("hotel") Hotel hotel, Model model) {
		hotel = hotelService.save(hotel);
		model.addAttribute("message", "hotel with id " + hotel.getId()
				+ " added successfully!");
		return "redirect:/index.obj";
		
	}

	@RequestMapping("/listall.obj")
	
	public String getStudentDetails(Model model) {

		try 
		{
			List<Hotel> list = hotelService.showAllhotel();
			if (list.isEmpty()) {
				String msg = "There are no Students";
				model.addAttribute("msg", msg);
				return "myError";
			}
			
			// Add the attribute to the model

			/***********************************************************
			 * Method Name:  myError Return type:String Parameters:Object of type
			 * Model is for setting attribute
			 * 
			 * @author  
			 ***********************************************************/
			model.addAttribute("list", list);
			return "listall";
		} 
		
		catch (DataAccessException dataAccessException) {
			model.addAttribute("msg", "Technical Problem..Please Try Later!!");
			return "myError";
	}

}
}