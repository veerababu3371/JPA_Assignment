package com.cg.entities;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
@Entity
public class Hotel implements Serializable 
{
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="seq")
	@SequenceGenerator(name="seq",sequenceName="seq_htl_id",
	allocationSize=1)
	private int Id;
	private String Name;
	private String Rating;
	private int Rate;
	private int Avaliable_Rooms;
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getRating() {
		return Rating;
	}
	public void setRating(String rating) {
		Rating = rating;
	}
	public int getRate() {
		return Rate;
	}
	public void setRate(int rate) {
		Rate = rate;
	}
	public int getAvaliable_Rooms() {
		return Avaliable_Rooms;
	}
	public void setAvaliable_Rooms(int avaliable_Rooms) {
		Avaliable_Rooms = avaliable_Rooms;
	}
	
	

}
