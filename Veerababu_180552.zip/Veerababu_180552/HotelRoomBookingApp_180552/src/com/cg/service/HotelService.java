package com.cg.service;

import java.util.List;

import com.cg.entities.Hotel;


public interface HotelService {
	public Hotel save(Hotel hotel);
	public List<Hotel> showAllhotel();
	//public Hotel findById(int id);
	//public Hotel delete(int id);
	public boolean isValidHotelId(int studentId);
	 
}
