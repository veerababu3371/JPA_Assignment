package com.cg.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.HotelRepository;
import com.cg.dao.HotelRepositoryImpl;
 
import com.cg.entities.Hotel;
@Service
@Transactional
public class HotelServiceImpl implements HotelService{
	@Autowired
	private HotelRepository repository;

	public HotelServiceImpl() {
		repository = new HotelRepositoryImpl(); 
	}

	@Override
	public Hotel save(Hotel hotel) {
		// TODO Auto-generated method stub
		return repository.save(hotel);
	}

	@Override
	public List<Hotel> showAllhotel() {
		// TODO Auto-generated method stub
		return repository.showAllHotel();
	}

	@Override
	public boolean isValidHotelId(int hotelId) {
		// TODO Auto-generated method stub
		return repository.isValidHotelId(hotelId);
	}

}
