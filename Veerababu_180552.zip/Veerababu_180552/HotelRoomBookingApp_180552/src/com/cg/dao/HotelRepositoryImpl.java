package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import com.cg.entities.Hotel;
 

public class HotelRepositoryImpl implements HotelRepository{
	@PersistenceContext
	private EntityManager entityManager;
	@Override
	public Hotel save(Hotel hotel) {
		// TODO Auto-generated method stub
		return  hotel;
	}
	 

	@Override
	public List<Hotel> showAllHotel() {
		String qry = "SELECT htl FROM Hotel htl";
		TypedQuery<Hotel> query = entityManager.createQuery(
				qry, Hotel.class);
		return query.getResultList();
	}

	@Override
	public boolean isValidHotelId(int hotelId) {
		boolean status=false;
		System.out.println("hotelId="+hotelId);
    	String sql="SELECT 1 FROM hoteldetails WHERE hotelId=?";
		Object[] params=new Object[]{hotelId};
		int iStatus= entityManager.merge(hotelId);
		if(iStatus>0)
		{
			status=true;
		}
		
		return status;
		
	}

	
	

}
