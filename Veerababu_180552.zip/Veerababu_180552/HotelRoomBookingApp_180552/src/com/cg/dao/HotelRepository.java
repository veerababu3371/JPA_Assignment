package com.cg.dao;

import java.util.List;

import com.cg.entities.Hotel;

public interface HotelRepository {
	public Hotel save(Hotel hotel);
	public List<Hotel> showAllHotel();
 	public boolean isValidHotelId(int hotelId);

}
