import { Component, OnInit } from '@angular/core';
import { IEmployee } from './iemployee';
@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
  empName: string = 'Amit';
  department = 'IT';
  detail: IEmployee = {
    age: 34,
    id: 1,
    name: 'Emp2'
  };

  list: Array<IEmployee> = [
    {
      age: 34,
      id: 1,
      name: 'Emp1'
    },
    {
      age: 35,
      id: 2,
      name: 'Emp2'
    },
    {
      age: 38,
      id: 3,
      name: 'Emp3'
    }
  ];

  isValid = false;

  constructor() { }

  ngOnInit() {
  }

  toggle() {
    this.isValid = !this.isValid;
  }

}
